# CS_core
 Il mio core in alpha
