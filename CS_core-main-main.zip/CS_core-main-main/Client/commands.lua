RegisterCommand("SkinSaved", function ()
    SaveSkin()
end)