CS                      = {}
CS.Game                 = {}
CS.ServerCallbacks      = {}
CS.CurrentRequestId     = 0


CS.Key = {
    {name = "crouch", key = "LCONTROL", label = "Accovacciati"},
    {name = "handsup", key = "X", label = "Alza le mani"},
    {name = "inventory", key = "I", label = "Apri lo zaino"},
    {name = "finger", key = "B", label = "Punta il dito"}
}



local keyStates = {}

for _, mapping in pairs(CS.Key) do
    RegisterKeyMapping(mapping.name, mapping.label, 'keyboard', mapping.key)
    keyStates[mapping.name] = false
end

for _, mapping in pairs(CS.Key) do
    RegisterCommand(mapping.name, function()
        keyStates[mapping.name] = true
    end, false)
end

CS.Game.KeyPress = function(key)
    if keyStates[key] then
        keyStates[key] = false
        return true
    else
        return false
    end
end

CS.SaveSkin = function()
    TriggerEvent('skinchanger:getSkin', function(skin)
        TriggerServerEvent("Player:Skin:Saved", json.encode(skin))
        print(json.encode(skin))
    end)
end



-- Callbacks

RegisterNetEvent('CS:serverCallback')
AddEventHandler('CS:serverCallback', function(requestId, ...)
	CS.ServerCallbacks[requestId](...)
	CS.ServerCallbacks[requestId] = nil
end)


CS.TriggerServerCallback = function(name, cb, ...)
	CS.ServerCallbacks[CS.CurrentRequestId] = cb

	TriggerServerEvent('CS:triggerServerCallback', name, CS.CurrentRequestId, ...)

	if CS.CurrentRequestId < 65535 then
		CS.CurrentRequestId = CS.CurrentRequestId + 1
	else
		CS.CurrentRequestId = 0
	end
end



AddEventHandler('CS:FUNZIONICORE', function(cb)
	cb(CS)
end)

function CSFUNZIONICORE()
	return CS
end