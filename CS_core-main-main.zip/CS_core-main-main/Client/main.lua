AddEventHandler("playerSpawned",function ()
    TriggerServerEvent("playerSpawned")
end)

RegisterNetEvent("onPlayerSpawned")
AddEventHandler("onPlayerSpawned", function (X, Y, Z, skin)

    local defaultModel = GetHashKey("mp_m_freemode_01")
    RequestModel(defaultModel)
    while not HasModelLoaded(defaultModel) do
        Citizen.Wait(1)
    end
    SetPlayerModel(PlayerPedId(), defaultModel)
    
    TriggerEvent('skinchanger:loadSkin', skin)

    SetEntityCoords(PlayerPedId(), X, Y, Z, 1, 0, 0, 1)
end)

Citizen.CreateThread(function ()
    while true do
        Citizen.Wait(5000)
        local x, y, z = table.unpack(GetEntityCoords(PlayerPedId()))
        TriggerServerEvent("Player:Update", x, y, z)
       
    end
end)


SetCanAttackFriendly(PlayerPedId(), true, false)
NetworkSetFriendlyFireOption(true)

