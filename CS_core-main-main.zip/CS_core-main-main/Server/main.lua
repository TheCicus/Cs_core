---- Inseriamo licensa e nome nel db --
CS = {}

CS.Player = {}

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local players_data = GetPlayerIdentifiers(source)
    local player_name = GetPlayerName(source)
    local license 

    for k, v in pairs(players_data) do
        if string.match(v, 'license:') then
            license = v
        end
    end

    local playerExists = MySQL.Sync.fetchScalar('SELECT COUNT(*) FROM `player_stats` WHERE license = @license', {
        ['@license'] = license
    })

    if playerExists > 0 then
        print("^2[INFO]^0 Giocatore ^5" .. player_name .. "^0 è entrato")
    else
        print("^3[BENVENUTO]^0 Giocatore ^5" .. player_name)
        MySQL.insert('INSERT INTO `player_stats` (license, name) VALUES (?, ?)', {
            license, player_name
        })
        MySQL.insert('INSERT INTO `inventory` (license) VALUES (?)', {
            license
        })
    end
end)

-- Giocatore Uscito --

AddEventHandler('playerDropped', function (reason)
    print("^2[INFO]^0 Giocatore ^5" .. GetPlayerName(source) .. "^0 (Motivo: ".. reason ..") ")
    print("^2[INFO]^0 Giocatore ^5" .. GetPlayerName(source) .. "^0 salvato")
    CS.Player = {}
end)


-- Giocatore Update --

RegisterNetEvent("Player:Update")
AddEventHandler("Player:Update", function (LX, LY, LZ)
    local license  
    local players_data = GetPlayerIdentifiers(source)

    for k, v in pairs(players_data) do
        if string.match(v, 'license:') then
            license = v
        end
    end
    
    MySQL.update('UPDATE player_stats SET coords = ? WHERE license = ?', {
        "{ " .. LX .. ", " .. LY .. "," .. LZ .. "}", license
    })
end)

-- Skin Giocatore --
RegisterNetEvent("Player:Skin:Saved")
AddEventHandler("Player:Skin:Saved", function (skin)
    local license  
    local players_data = GetPlayerIdentifiers(source)

    for k, v in pairs(players_data) do
        if string.match(v, 'license:') then
            license = v
        end
    end

   
    MySQL.update('UPDATE player_stats SET skin = ? WHERE license = ?', {
        skin, license
    })
end)


RegisterNetEvent("playerSpawned")
AddEventHandler("playerSpawned", function ()
    local license  
    local source = source
    local players_data = GetPlayerIdentifiers(source)

    for k, v in pairs(players_data) do
        if string.match(v, 'license:') then
            license = v
        end
    end

    MySQL.Async.fetchAll("SELECT * FROM player_stats WHERE license = @license", {
        ["@license"] = license
    }, function (result)
        local SpawnCoords = json.decode(result[1].coords)
        local skin = json.decode(result[1].skin)
    
        TriggerClientEvent("onPlayerSpawned", source, SpawnCoords[1], SpawnCoords[2], SpawnCoords[3], skin)
    end)
end)





