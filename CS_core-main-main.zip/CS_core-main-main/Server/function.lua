-- CS Framwork Function --

CS = {}
CS.UsableItemsCallbacks = {}
CS.ServerCallbacks = {}


-- GetPlayer Function --

CS.GetPlayerLicense = function()
    for _, id in ipairs(GetPlayers()) do
        local identifiers = GetPlayerIdentifiers(id)
        for _, identifier in ipairs(identifiers) do
            if string.match(identifier, "license") then
                return identifier
            end
        end
    end
end

-- Aggiungere un item nel inventario --

CS.AddItem = function(item, count, player)

    local Oldinventory = CS.GetAllInventoryItem(player)
    local itemLabel = GetItem(item, "label")
    local itemDesc = GetItem(item, "description")
    local itemType = GetItem(item, "type")
    local itemId = GetItem(item, "id")
    local itemId2 = GetItem(item, "itemId2")
    local type_clot = GetItem(item, "type_clot")
 
    local NewItem = {}

    for itemName, oldItemData in pairs(Oldinventory) do
        local name = oldItemData.name
        local label = oldItemData.label
        local oldCount = oldItemData.count
        local OldDesc = oldItemData.desc
        local OldType = oldItemData.type
        local OldId 
        local Oldid2
        local Oldtype_clot

        if oldItemData.id then
            OldId = oldItemData.id
        end

        if oldItemData.type_clot then
            Oldtype_clot = oldItemData.type_clot
        end

        if oldItemData.Oldid2 then
            Oldid2 = oldItemData.Oldid2
        end

        NewItem[itemName] = {
            name = name,
            count = oldCount,
            label = label,
            desc = OldDesc,
            id = OldId,
            type = OldType,
            id2 = Oldid2,
            type_clot = Oldtype_clot,
        }
    end

    if NewItem[item] then

        NewItem[item].count = NewItem[item].count + count
    else
        NewItem[item] = {
            name = item,
            count = count,
            label = itemLabel,
            desc = itemDesc,
            id = itemId,
            type = itemType,
            id2 = itemId2,
            type_clot = type_clot,
        }
    end

    MySQL.update('UPDATE player_stats SET inventory = ? WHERE license = ?', {
        json.encode(NewItem), player
    })

end

-- Darsi l'iventario di un giocatore--

CS.GetAllInventoryItem = function(playerLicense)
    local response = nil
    local result = MySQL.Sync.fetchAll('SELECT `inventory` FROM `player_stats` WHERE `license` = ?', { playerLicense })

    if result and #result > 0 then
        local inventoryJson = result[1].inventory
        response = json.decode(inventoryJson)
    end

    return response
end

-- Rimuovere un item nel inventario --

CS.RemoveItem = function (item, count, player)
    local inventory = CS.GetAllInventoryItem(player)
    local isItem = tonumber(inventory[item].count)  -- Converti il valore in un numero
    
    if isItem and isItem > tonumber(count) then
        inventory[item].count = isItem - tonumber(count)
    elseif isItem and (isItem == tonumber(count) or isItem < tonumber(count)) then
        inventory[item] = nil
    end

    MySQL.update('UPDATE player_stats SET inventory = ? WHERE license = ?', {
        json.encode(inventory), player
    })
 
end
-- Registare un funzioni di un uso di un Item --

CS.RegisterUseItem = function(item, cb)
    CS.UsableItemsCallbacks[item] = cb
end

-- Usare un item Registrato --

CS.UseItem = function(item)
    if CS.UsableItemsCallbacks[item] then
        CS.UsableItemsCallbacks[item](item)
    end
end

-- Funzioni locali --

function GetItem(item, type)
    local response = nil

    local result = MySQL.Sync.fetchAll('SELECT * FROM `items` WHERE `name` = ?', { item })

    if result and #result > 0 then
        if type == "label" then
            response = result[1].label
        elseif type == "description" then
            response = result[1].description
        elseif type == "type" then
            response = result[1].type
        elseif type == "id" then
            if result[1].id then
                response = result[1].id
            end
        elseif type == "itemId2" then
            if result[1].id2 then
                response = result[1].id2
            end
        elseif type == "type_clot" then
            if result[1].type_clot then
                response = result[1].type_clot
            end
        end
        
       
    end

    return response
end


-- Callbacks --

CS.RegisterServerCallback = function(name, cb)
	CS.ServerCallbacks[name] = cb
end

CS.TriggerServerCallback = function(name, requestId, source, cb, ...)
	if CS.ServerCallbacks[name] ~= nil then
		CS.ServerCallbacks[name](source, cb, ...)
	else
		print('es_extended: TriggerServerCallback => [' .. name .. '] does not exist')
	end
end

RegisterServerEvent('CS:triggerServerCallback')
AddEventHandler('CS:triggerServerCallback', function(name, requestId, ...)
	local _source = source

	CS.TriggerServerCallback(name, requestId, _source, function(...)
		TriggerClientEvent('CS:serverCallback', _source, requestId, ...)
	end, ...)
end)




RegisterCommand("giveitem", function (source, args, rawCommand)
    CS.AddItem(args[1], args[2], CS.GetPlayerLicense())
end)


RegisterCommand("removeitem", function (source, args, rawCommand)
    CS.RemoveItem(args[1], args[2], CS.GetPlayerLicense())
end)




-- Export Framwork--

AddEventHandler('CS:FUNZIONICORE', function(cb)
	cb(CS)
end)

function CSFUNZIONICORE()
	return CS
end