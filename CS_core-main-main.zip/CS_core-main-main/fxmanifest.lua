fx_version('cerulean')
games({ 'gta5' })


server_scripts({
    '@oxmysql/lib/MySQL.lua',
    'Server/main.lua',
    'Server/function.lua'
});

client_scripts({
    'Client/main.lua',
    'Client/function.lua',
    'Client/commands.lua'

});


exports {
	'CSFUNZIONICORE'
}

server_exports {
	'CSFUNZIONICORE'
}
